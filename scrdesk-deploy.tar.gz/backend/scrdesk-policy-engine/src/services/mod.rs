// Policy evaluation and enforcement logic
