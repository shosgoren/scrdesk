// Services module for business logic
// Will be expanded as needed
