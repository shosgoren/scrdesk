// Middleware for authentication, tenant isolation, rate limiting, etc.
